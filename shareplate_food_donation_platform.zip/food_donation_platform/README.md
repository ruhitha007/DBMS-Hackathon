# SharePlate – Food Donation Management Platform

Flask + SQLite platform connecting food donors (restaurants, hotels, supermarkets, individuals) with NGOs that distribute surplus food. It is a **multi-page application**: every module is its own server-rendered Flask page, and each page reads and writes real data through the REST API.

## Run locally
```
pip install -r requirements.txt
flask --app app seed        # optional demo data + demo accounts
python app.py               # http://127.0.0.1:5000
```
Demo accounts (password `Password@123`): `admin@shareplate.local`, `donor@example.com`, `hotel@example.com`, `ngo@example.com`, `rotibank@example.com`.
Create your own admin with `flask --app app create-admin`. Without seeding, start by registering a donor and an NGO on `/register`.

> The data model gained new tables/columns (users, donor type, etc.). If you have an old `instance/food_donation.db`, delete it first.

## Pages
| URL | Template | Purpose |
|---|---|---|
| `/` | index.html | Home with live platform numbers |
| `/login`, `/register` | login.html, register.html | Authentication; register as donor or NGO |
| `/dashboard` | dashboard.html | Stats, 7-day chart, priority queue, expiring food |
| `/donors`, `/ngos` | donors.html, ngos.html | Directory; admins add/edit/delete |
| `/food-packages` | food-packages.html | List, edit, withdraw packages; NGOs request food |
| `/requests` | requests.html | Approve (creates assignment) / reject / cancel |
| `/assignments` | assignments.html | Edit, mark in transit, record distribution, cancel |
| `/distribution-history` | distribution-history.html | Completed distributions, search, CSV export |
| `/profile` | profile.html | Account details and password |

All pages except home/login/register require login (redirects to `/login?next=…`).

## Roles
- **Donor** – manages own packages; approves/rejects requests for them; updates assignments.
- **NGO** – requests food, cancels own pending requests; marks pickups in transit / distributed.
- **Admin** – everything, plus managing donor and NGO records.
Lists (requests, assignments, history, stats) are automatically scoped to what each user is involved in.

## REST API (all JSON, session cookie auth)
- Auth: `POST /api/auth/register|login|logout`, `GET /api/auth/me`
- Profile: `GET|PUT /api/profile`, `POST /api/profile/password`
- Donors / NGOs: `GET|POST /api/donors|ngos`, `PUT|DELETE /api/donors|ngos/<id>` (writes admin-only)
- Packages: `GET|POST /api/packages`, `PUT|DELETE /api/packages/<id>`
- Requests: `GET|POST /api/requests`, `POST /api/requests/<id>/approve|reject|cancel`, `GET /api/priority`
- Assignments: `GET /api/assignments`, `PUT /api/assignments/<id>`, `POST …/<id>/start|complete|cancel`
- `GET /api/history`, `GET /api/stats`, `GET /api/public/stats`, `GET /api/health`

Behaviour worth knowing: datetimes are stored in UTC and shown in the viewer's local time; approving a request deducts stock and creates an assignment; a partial delivery or cancelled assignment returns the unused quantity to the package; packages past their expiry are marked `expired` automatically; request status flows `pending → approved → completed`.

## Tests
`python -m unittest discover -s tests -v` (uses a throwaway database).

## Before production
Set `SECRET_KEY`, serve over HTTPS (and set `SESSION_COOKIE_SECURE`), add login rate-limiting/email verification, use a production WSGI server, and follow local food-safety rules for donated food.
