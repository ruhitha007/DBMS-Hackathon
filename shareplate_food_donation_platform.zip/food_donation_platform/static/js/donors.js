(function () {
  const { $, esc } = SP;
  let rows = [], type = 'all', query = '';
  const form = $('#orgForm');

  function render() {
    const q = query.toLowerCase();
    const list = rows.filter((d) => (type === 'all' || d.donor_type === type) &&
      (!q || [d.name, d.email, d.address, d.phone].join(' ').toLowerCase().includes(q)));
    $('#rows').innerHTML = list.length ? list.map((d) => `<tr>
      <td><strong>${esc(d.name)}</strong></td>
      <td>${esc(SP.label(d.donor_type))}</td>
      <td>${esc(d.email)}<span class="sub">${esc(d.phone || '')}</span></td>
      <td>${esc(d.address || '—')}</td>
      <td class="num">${d.package_count}</td><td class="num">${d.distribution_count}</td>
      ${SP.isAdmin ? `<td class="actions"><button class="btn btn-ghost btn-sm" data-edit="${d.id}">Edit</button><button class="btn btn-danger btn-sm" data-del="${d.id}">Delete</button></td>` : ''}
    </tr>`).join('') : `<tr><td colspan="7">${SP.empty('No donors found', rows.length ? 'Try a different search or filter.' : 'Donors will appear here once they register.')}</td></tr>`;
  }

  function renderChips() {
    const counts = rows.reduce((m, d) => (m[d.donor_type] = (m[d.donor_type] || 0) + 1, m), {});
    const types = ['all', ...Object.keys(counts).sort()];
    $('#typeChips').innerHTML = types.map((t) => `<button class="chip ${t === type ? 'active' : ''}" data-type="${t}">${t === 'all' ? 'All' : SP.label(t)}<span class="count">${t === 'all' ? rows.length : counts[t]}</span></button>`).join('');
  }

  async function load() {
    try { rows = await SP.api('/api/donors'); renderChips(); render(); }
    catch (e) { $('#rows').innerHTML = `<tr><td colspan="7">${SP.empty('Could not load donors', e.message)}</td></tr>`; }
  }

  $('#search').addEventListener('input', SP.debounce((e) => { query = e.target.value.trim(); render(); }));
  $('#typeChips').addEventListener('click', (e) => { const b = e.target.closest('[data-type]'); if (b) { type = b.dataset.type; renderChips(); render(); } });

  if (SP.isAdmin) {
    const dlg = $('#formDialog');
    function openForm(d) {
      form.reset(); SP.formMessage(form, '');
      form.elements.id.value = d ? d.id : '';
      $('#dlgTitle').textContent = d ? 'Edit donor' : 'Add donor';
      if (d) { form.elements.name.value = d.name; form.email.value = d.email; form.phone.value = d.phone; form.address.value = d.address; form.donor_type.value = d.donor_type; }
      SP.openDialog(dlg);
    }
    $('#addBtn').addEventListener('click', () => openForm(null));
    $('#rows').addEventListener('click', async (e) => {
      const edit = e.target.closest('[data-edit]'), del = e.target.closest('[data-del]');
      if (edit) openForm(rows.find((d) => d.id == edit.dataset.edit));
      if (del) {
        const d = rows.find((x) => x.id == del.dataset.del);
        if (!(await SP.confirm('Delete donor?', `${d.name} will be removed. Donors with food packages on record cannot be deleted.`, 'Delete', true))) return;
        try { await SP.api(`/api/donors/${d.id}`, { method: 'DELETE' }); SP.toast('Donor deleted'); load(); }
        catch (err) { SP.toast(err.message, 'error'); }
      }
    });
    SP.bindForm(form, async (data) => {
      const id = data.id; delete data.id;
      await SP.api(id ? `/api/donors/${id}` : '/api/donors', { method: id ? 'PUT' : 'POST', body: data });
      dlg.close(); SP.toast(id ? 'Donor updated' : 'Donor added'); load();
    });
  }
  load();
})();
