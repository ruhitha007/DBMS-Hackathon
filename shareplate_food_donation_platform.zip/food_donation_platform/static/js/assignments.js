(function () {
  const { $, esc } = SP;
  let rows = [], status = 'active', query = '';
  const STATUSES = ['active', 'assigned', 'in_transit', 'completed', 'cancelled', 'all'];
  const chipLabel = (s) => s === 'active' ? 'Active' : s === 'all' ? 'All' : SP.label(s);
  const isActive = (a) => a.status === 'assigned' || a.status === 'in_transit';
  const canManage = SP.isDonor || SP.isAdmin;

  function track(a) {
    if (a.status === 'cancelled') return '<div class="track"><span class="bad">Cancelled</span></div>';
    const step = { assigned: 1, in_transit: 2, completed: 3 }[a.status];
    const cls = (n) => (step >= n ? 'done' : '');
    return `<div class="track"><span class="${cls(1)}">Assigned</span><span class="sep"></span><span class="${cls(2)}">In transit</span><span class="sep"></span><span class="${cls(3)}">Distributed</span></div>`;
  }

  function renderChips() {
    $('#statusChips').innerHTML = STATUSES.map((s) => {
      const n = s === 'all' ? rows.length : s === 'active' ? rows.filter(isActive).length : rows.filter((a) => a.status === s).length;
      return `<button class="chip ${s === status ? 'active' : ''}" data-status="${s}">${chipLabel(s)}<span class="count">${n}</span></button>`;
    }).join('');
  }

  function actions(a) {
    if (!isActive(a)) return '';
    const b = [];
    if (a.status === 'assigned') b.push(`<button class="btn btn-ghost btn-sm" data-start="${a.id}">Mark in transit</button>`);
    b.push(`<button class="btn btn-primary btn-sm" data-complete="${a.id}">Mark distributed</button>`);
    if (canManage) b.push(`<button class="btn btn-ghost btn-sm" data-edit="${a.id}">Edit</button><button class="btn btn-danger btn-sm" data-cancel="${a.id}">Cancel</button>`);
    return b.join('');
  }

  function render() {
    const q = query.toLowerCase();
    const list = rows.filter((a) => (status === 'all' || (status === 'active' ? isActive(a) : a.status === status)) &&
      (!q || [a.food_name, a.ngo_name, a.donor_name, a.assigned_to].join(' ').toLowerCase().includes(q)));
    $('#rows').innerHTML = list.length ? list.map((a) => `<tr>
      <td><strong>${esc(a.food_name)}</strong><span class="sub">Assignment #${a.id} · ${SP.pill(a.status)}</span></td>
      <td>${esc(a.donor_name)}<span class="sub">to ${esc(a.ngo_name)}</span></td>
      <td class="num nowrap">${SP.fmtQty(a.quantity)} ${esc(a.unit)}</td>
      <td>${a.pickup_time ? SP.fmtDateTime(a.pickup_time) : '<span class="muted">Not scheduled</span>'}<span class="sub">${esc(a.assigned_to)} · ${esc(a.pickup_location)}</span></td>
      <td>${track(a)}</td><td class="actions">${actions(a)}</td></tr>`).join('')
      : `<tr><td colspan="6">${SP.empty('No assignments here', status === 'active' ? 'Approve a request to create a pickup assignment.' : 'Try a different filter.')}</td></tr>`;
  }

  async function load() {
    try { rows = await SP.api('/api/assignments'); renderChips(); render(); }
    catch (e) { $('#rows').innerHTML = `<tr><td colspan="6">${SP.empty('Could not load assignments', e.message)}</td></tr>`; }
  }

  $('#search').addEventListener('input', SP.debounce((e) => { query = e.target.value.trim(); render(); }));
  $('#statusChips').addEventListener('click', (e) => { const b = e.target.closest('[data-status]'); if (b) { status = b.dataset.status; renderChips(); render(); } });

  const editDlg = $('#editDialog'), editForm = $('#editForm');
  const doneDlg = $('#completeDialog'), doneForm = $('#completeForm');
  const find = (btn, key) => rows.find((x) => x.id == btn.dataset[key]);

  $('#rows').addEventListener('click', async (e) => {
    const start = e.target.closest('[data-start]'), complete = e.target.closest('[data-complete]');
    const edit = e.target.closest('[data-edit]'), cancel = e.target.closest('[data-cancel]');
    try {
      if (start) { await SP.api(`/api/assignments/${find(start, 'start').id}/start`, { method: 'POST', body: {} }); SP.toast('Marked as in transit'); load(); }
      if (complete) {
        const a = find(complete, 'complete');
        doneForm.reset(); SP.formMessage(doneForm, '');
        doneForm.elements.id.value = a.id;
        doneForm.distributed_quantity.value = a.quantity; doneForm.distributed_quantity.max = a.quantity;
        $('#c_qtyLabel').textContent = `Quantity distributed (${a.unit})`;
        $('#completeSummary').textContent = `${a.food_name}: ${SP.fmtQty(a.quantity)} ${a.unit} approved for ${a.ngo_name}.`;
        SP.openDialog(doneDlg);
      }
      if (edit) {
        const a = find(edit, 'edit');
        editForm.reset(); SP.formMessage(editForm, '');
        editForm.elements.id.value = a.id; editForm.assigned_to.value = a.assigned_to; editForm.pickup_time.value = SP.toLocalInput(a.pickup_time);
        $('#editSummary').textContent = `${a.food_name} for ${a.ngo_name}.`;
        SP.openDialog(editDlg);
      }
      if (cancel) {
        const a = find(cancel, 'cancel');
        if (await SP.confirm('Cancel this assignment?', `The ${SP.fmtQty(a.quantity)} ${a.unit} of ${a.food_name} goes back to the package and the request is closed.`, 'Cancel assignment', true)) {
          await SP.api(`/api/assignments/${a.id}/cancel`, { method: 'POST', body: {} }); SP.toast('Assignment cancelled'); load();
        }
      }
    } catch (err) { SP.toast(err.message, 'error'); }
  });

  SP.bindForm(editForm, async (data) => {
    const id = data.id; delete data.id; data.pickup_time = SP.toIso(data.pickup_time);
    await SP.api(`/api/assignments/${id}`, { method: 'PUT', body: data });
    editDlg.close(); SP.toast('Assignment updated'); load();
  });
  SP.bindForm(doneForm, async (data) => {
    const id = data.id; delete data.id;
    await SP.api(`/api/assignments/${id}/complete`, { method: 'POST', body: data });
    doneDlg.close(); SP.toast('Distribution recorded'); status = 'active'; load();
  });
  load();
})();
