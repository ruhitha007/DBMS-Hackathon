(async function () {
  const { $, esc } = SP;
  const form = $('#profileForm');
  const labels = { packages: 'Packages listed', requests: 'Requests made', distributions: 'Distributions', donors: 'Donors', ngos: 'NGOs' };

  async function load() {
    const p = await SP.api('/api/profile');
    form.elements.name.value = p.name; form.elements.email.value = p.email; form.elements.phone.value = p.phone || '';
    form.elements.address.value = p.address || '';
    if (p.donor_type) form.elements.donor_type.value = p.donor_type;
    $('#typeField').classList.toggle('hidden', !SP.isDonor);
    $('#addressField').classList.toggle('hidden', SP.isAdmin);
    form.elements.phone.closest('.field').classList.toggle('hidden', SP.isAdmin);
    $('#pName').textContent = p.name; $('#pAvatar').textContent = p.name.charAt(0).toUpperCase();
    $('#pRole').textContent = SP.isAdmin ? 'Administrator' : SP.isNgo ? 'NGO account' : `Donor account · ${SP.label(p.donor_type)}`;
    $('#pSince').textContent = 'Member since ' + SP.fmtDate(p.created_at);
    $('#pStats').innerHTML = Object.entries(p.summary).filter(([, v]) => v !== null)
      .map(([k, v]) => `<div><strong>${SP.fmtQty(v)}</strong><small>${esc(labels[k] || k)}</small></div>`).join('');
  }

  SP.bindForm(form, async (data) => {
    await SP.api('/api/profile', { method: 'PUT', body: data });
    await load();
    SP.formMessage(form, 'Profile updated.', true);
  });
  SP.bindForm($('#passwordForm'), async (data, f) => {
    await SP.api('/api/profile/password', { method: 'POST', body: data });
    f.reset(); SP.formMessage(f, 'Password updated.', true);
  });
  try { await load(); } catch (e) { SP.toast(e.message, 'error'); }
})();
