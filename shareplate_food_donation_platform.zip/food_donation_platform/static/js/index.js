(async function () {
  const { $, esc } = SP;
  try {
    const s = await SP.api('/api/public/stats');
    $('#sDistributions').textContent = SP.fmtQty(s.distributions);
    $('#sAvailable').textContent = SP.fmtQty(s.available_packages);
    $('#sDonors').textContent = SP.fmtQty(s.donors);
    $('#sNgos').textContent = SP.fmtQty(s.ngos);
    $('#sQuantity').textContent = s.distributions ? SP.fmtTotals(s.quantity_by_unit) : 'nothing yet';
    $('#availableNow').innerHTML = s.available_now.length ? s.available_now.map((p) => {
      const left = SP.timeLeft(p.expiry_time);
      return `<article class="pkg">
        <div class="pkg-top"><h3>${esc(p.food_name)}</h3><span class="pill pill-available">Available</span></div>
        <div class="donor">${esc(p.donor_name)} · ${esc(SP.label(p.donor_type))}</div>
        <div class="qty">${SP.fmtQty(p.quantity)} <small>${esc(p.unit)}</small></div>
        <p class="${left.cls}" style="margin:6px 0 0">${left.text}</p>
      </article>`;
    }).join('') : SP.empty('No food listed right now', 'New packages appear here as donors add them.');
  } catch (e) {
    $('#availableNow').innerHTML = SP.empty('Could not load live data', e.message);
  }
})();
