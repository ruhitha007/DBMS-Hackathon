(async function () {
  const { $, esc } = SP;
  const actions = [];
  if (SP.isDonor || SP.isAdmin) actions.push('<a class="btn btn-accent" href="/food-packages?new=1">List food package</a>');
  if (SP.isNgo) actions.push('<a class="btn btn-accent" href="/food-packages">Find food to request</a>');
  actions.push('<a class="btn btn-ghost" href="/requests">View requests</a>');
  $('#headActions').innerHTML = actions.join('');
  $('#subtitle').textContent = {
    donor: 'Your surplus food, incoming requests and pickups at a glance.',
    ngo: 'Available food, your requests and pickups at a glance.',
    admin: 'Platform-wide activity across all donors and NGOs.',
  }[SP.role];

  try {
    const [s, priority] = await Promise.all([SP.api('/api/stats'), SP.api('/api/priority')]);
    $('#stAvailable').textContent = SP.fmtQty(s.available_packages);
    $('#stPending').textContent = SP.fmtQty(s.pending_requests);
    $('#stActive').textContent = SP.fmtQty(s.active_assignments);
    $('#stDone').textContent = SP.fmtQty(s.completed_distributions);
    $('#stQty').textContent = s.completed_distributions ? SP.fmtTotals(s.quantity_by_unit) : 'None recorded yet';

    // 7-day chart
    const max = Math.max(1, ...s.daily_distributions.map((d) => d.count));
    $('#chart').innerHTML = s.daily_distributions.map((d, i, all) => {
      const day = new Date(d.date + 'T00:00:00Z').toLocaleDateString([], { weekday: 'short', timeZone: 'UTC' });
      return `<div class="bar ${i === all.length - 1 ? 'today' : ''}" title="${d.count} on ${esc(d.date)}"><b>${d.count || ''}</b><i style="height:${Math.round((d.count / max) * 100)}%"></i><span>${day}</span></div>`;
    }).join('');

    // priority queue
    $('#priority').innerHTML = priority.length ? `<ul class="list">${priority.slice(0, 5).map((r) => `
      <li><div class="main"><strong>${esc(r.food_name)}</strong><small>${esc(r.ngo_name)} · ${esc(SP.label(r.urgency))} · ${r.hours_until_expiry > 0 ? r.hours_until_expiry + 'h to expiry' : 'expired'}</small></div>
      <span class="score" title="Priority score">${r.priority_score}</span></li>`).join('')}</ul>`
      : SP.empty('Nothing waiting', 'Pending requests will be ranked here.');

    // expiring soon
    $('#expiring').innerHTML = s.expiring_soon.length ? `<ul class="list">${s.expiring_soon.map((p) => {
      const left = SP.timeLeft(p.expiry_time);
      return `<li><div class="main"><strong>${esc(p.food_name)}</strong><small>${SP.fmtQty(p.quantity)} ${esc(p.unit)} · ${esc(p.donor_name)}</small></div><span class="${left.cls}">${left.text}</span></li>`;
    }).join('')}</ul>` : SP.empty('Nothing expiring soon', 'Packages close to their expiry time show up here.');

    // status breakdown
    const order = ['pending', 'approved', 'completed', 'rejected', 'cancelled', 'expired'];
    const total = Object.values(s.request_status).reduce((a, b) => a + b, 0);
    $('#statusMeters').innerHTML = total ? order.filter((k) => s.request_status[k]).map((k) => `
      <div class="meter"><div class="meter-top"><span>${SP.label(k)}</span><strong>${s.request_status[k]}</strong></div>
      <div class="meter-track"><i style="width:${(s.request_status[k] / total) * 100}%"></i></div></div>`).join('')
      : SP.empty('No requests yet');

    // recent requests
    $('#recent').innerHTML = s.recent_requests.length ? `<div class="table-wrap" style="box-shadow:none"><table>
      <thead><tr><th>Food</th><th>NGO</th><th class="num">Quantity</th><th>Urgency</th><th>Status</th><th>Requested</th></tr></thead><tbody>
      ${s.recent_requests.map((r) => `<tr><td><strong>${esc(r.food_name)}</strong><span class="sub">${esc(r.donor_name)}</span></td><td>${esc(r.ngo_name)}</td>
        <td class="num">${SP.fmtQty(r.requested_quantity)} ${esc(r.unit)}</td><td>${SP.pill(r.urgency)}</td><td>${SP.pill(r.status)}</td><td class="nowrap">${SP.fmtDateTime(r.created_at)}</td></tr>`).join('')}
      </tbody></table></div>` : SP.empty('No requests yet', SP.isNgo ? 'Browse food packages to send your first request.' : 'Requests from NGOs will appear here.');
  } catch (e) {
    SP.toast(e.message, 'error');
  }
})();
