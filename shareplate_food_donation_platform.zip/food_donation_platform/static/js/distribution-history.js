(function () {
  const { $, esc } = SP;
  let rows = [], query = '';
  if (SP.isNgo) $('#hPartnerLabel').textContent = 'Donors helped by';
  else if (SP.isDonor) $('#hPartnerLabel').textContent = 'NGOs reached';

  const view = () => {
    const q = query.toLowerCase();
    return rows.filter((h) => !q || [h.food_name, h.donor_name, h.ngo_name, h.assigned_to, h.notes].join(' ').toLowerCase().includes(q));
  };

  function render() {
    const list = view();
    $('#rows').innerHTML = list.length ? list.map((h) => `<tr>
      <td class="nowrap">${SP.fmtDateTime(h.distribution_date)}</td>
      <td><strong>${esc(h.food_name)}</strong><span class="sub">Assignment #${h.assignment_id}</span></td>
      <td>${esc(h.donor_name)}</td><td>${esc(h.ngo_name)}</td><td>${esc(h.assigned_to || '—')}</td>
      <td class="num nowrap">${SP.fmtQty(h.distributed_quantity)} ${esc(h.unit)}</td>
      <td>${esc(h.notes || '—')}</td></tr>`).join('')
      : `<tr><td colspan="7">${SP.empty('No distributions found', rows.length ? 'Try a different search.' : 'Completed distributions will be recorded here.')}</td></tr>`;
  }

  function summarise() {
    $('#hCount').textContent = SP.fmtQty(rows.length);
    const totals = {};
    rows.forEach((h) => { totals[h.unit] = (totals[h.unit] || 0) + h.distributed_quantity; });
    $('#hQty').textContent = rows.length ? SP.fmtTotals(totals) : '0';
    const partner = SP.isNgo ? 'donor_name' : 'ngo_name';
    $('#hPartners').textContent = new Set(rows.map((h) => h[partner])).size;
  }

  $('#search').addEventListener('input', SP.debounce((e) => { query = e.target.value.trim(); render(); }));

  $('#csvBtn').addEventListener('click', () => {
    const list = view();
    if (!list.length) return SP.toast('Nothing to export yet', 'error');
    const cell = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const lines = [['Date', 'Food', 'Donor', 'NGO', 'Handled by', 'Quantity', 'Unit', 'Notes'].join(',')].concat(
      list.map((h) => [h.distribution_date, h.food_name, h.donor_name, h.ngo_name, h.assigned_to, h.distributed_quantity, h.unit, h.notes].map(cell).join(',')));
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([lines.join('\n')], { type: 'text/csv' }));
    a.download = 'shareplate-distribution-history.csv';
    a.click(); URL.revokeObjectURL(a.href);
  });

  SP.api('/api/history').then((data) => { rows = data; summarise(); render(); })
    .catch((e) => { $('#rows').innerHTML = `<tr><td colspan="7">${SP.empty('Could not load history', e.message)}</td></tr>`; });
})();
