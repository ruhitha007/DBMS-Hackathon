(function () {
  const { $, esc } = SP;
  let rows = [], query = '';
  const form = $('#orgForm');

  function render() {
    const q = query.toLowerCase();
    const list = rows.filter((n) => !q || [n.name, n.email, n.address, n.phone].join(' ').toLowerCase().includes(q));
    $('#rows').innerHTML = list.length ? list.map((n) => `<tr>
      <td><strong>${esc(n.name)}</strong></td>
      <td>${esc(n.email)}<span class="sub">${esc(n.phone || '')}</span></td>
      <td>${esc(n.address || '—')}</td>
      <td class="num">${n.request_count}</td><td class="num">${n.distribution_count}</td>
      ${SP.isAdmin ? `<td class="actions"><button class="btn btn-ghost btn-sm" data-edit="${n.id}">Edit</button><button class="btn btn-danger btn-sm" data-del="${n.id}">Delete</button></td>` : ''}
    </tr>`).join('') : `<tr><td colspan="6">${SP.empty('No NGOs found', rows.length ? 'Try a different search.' : 'NGOs will appear here once they register.')}</td></tr>`;
  }

  async function load() {
    try { rows = await SP.api('/api/ngos'); render(); }
    catch (e) { $('#rows').innerHTML = `<tr><td colspan="6">${SP.empty('Could not load NGOs', e.message)}</td></tr>`; }
  }
  $('#search').addEventListener('input', SP.debounce((e) => { query = e.target.value.trim(); render(); }));

  if (SP.isAdmin) {
    const dlg = $('#formDialog');
    function openForm(n) {
      form.reset(); SP.formMessage(form, '');
      form.elements.id.value = n ? n.id : '';
      $('#dlgTitle').textContent = n ? 'Edit NGO' : 'Add NGO';
      if (n) { form.elements.name.value = n.name; form.email.value = n.email; form.phone.value = n.phone; form.address.value = n.address; }
      SP.openDialog(dlg);
    }
    $('#addBtn').addEventListener('click', () => openForm(null));
    $('#rows').addEventListener('click', async (e) => {
      const edit = e.target.closest('[data-edit]'), del = e.target.closest('[data-del]');
      if (edit) openForm(rows.find((n) => n.id == edit.dataset.edit));
      if (del) {
        const n = rows.find((x) => x.id == del.dataset.del);
        if (!(await SP.confirm('Delete NGO?', `${n.name} will be removed. NGOs with requests on record cannot be deleted.`, 'Delete', true))) return;
        try { await SP.api(`/api/ngos/${n.id}`, { method: 'DELETE' }); SP.toast('NGO deleted'); load(); }
        catch (err) { SP.toast(err.message, 'error'); }
      }
    });
    SP.bindForm(form, async (data) => {
      const id = data.id; delete data.id;
      await SP.api(id ? `/api/ngos/${id}` : '/api/ngos', { method: id ? 'PUT' : 'POST', body: data });
      dlg.close(); SP.toast(id ? 'NGO updated' : 'NGO added'); load();
    });
  }
  load();
})();
