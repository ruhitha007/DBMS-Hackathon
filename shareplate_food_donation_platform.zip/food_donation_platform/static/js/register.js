const form = SP.$('#registerForm');
function syncRole() {
  const role = form.role.value;
  SP.$('#typeField').classList.toggle('hidden', role !== 'donor');
  SP.$('#nameLabel').textContent = role === 'donor' ? 'Business or donor name' : 'Organisation name';
}
const preset = new URLSearchParams(location.search).get('role');
if (preset === 'ngo' || preset === 'donor') form.querySelector(`[name=role][value=${preset}]`).checked = true;
form.addEventListener('change', syncRole);
syncRole();
SP.bindForm(form, async (data) => {
  await SP.api('/api/auth/register', { method: 'POST', body: data });
  location.href = '/dashboard';
});
