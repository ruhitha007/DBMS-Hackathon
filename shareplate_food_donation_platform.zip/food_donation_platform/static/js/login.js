SP.bindForm(SP.$('#loginForm'), async (data) => {
  await SP.api('/api/auth/login', { method: 'POST', body: data });
  const next = new URLSearchParams(location.search).get('next');
  location.href = next && next.startsWith('/') && !next.startsWith('//') ? next : '/dashboard';
});
