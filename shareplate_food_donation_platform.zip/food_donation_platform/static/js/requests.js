(function () {
  const { $, esc } = SP;
  let rows = [], status = 'all', query = '', byPriority = false;
  const form = $('#approveForm'), dlg = $('#approveDialog');
  const STATUSES = ['all', 'pending', 'approved', 'completed', 'rejected', 'cancelled', 'expired'];

  $('#subtitle').textContent = {
    donor: 'Requests from NGOs for your food packages. Approve to create a pickup assignment.',
    ngo: 'Your organisation\'s requests and their progress.',
    admin: 'All requests across the platform.',
  }[SP.role];

  function renderChips() {
    $('#statusChips').innerHTML = STATUSES.map((s) => {
      const n = s === 'all' ? rows.length : rows.filter((r) => r.status === s).length;
      return `<button class="chip ${s === status ? 'active' : ''}" data-status="${s}">${s === 'all' ? 'All' : SP.label(s)}<span class="count">${n}</span></button>`;
    }).join('');
  }

  function actionsFor(r) {
    if (r.status !== 'pending') return r.assignment_id ? `<a class="btn btn-ghost btn-sm" href="/assignments">View assignment</a>` : '';
    const b = [];
    if (SP.isDonor || SP.isAdmin) b.push(`<button class="btn btn-primary btn-sm" data-approve="${r.id}">Approve</button><button class="btn btn-danger btn-sm" data-reject="${r.id}">Reject</button>`);
    if (SP.isNgo) b.push(`<button class="btn btn-danger btn-sm" data-cancel="${r.id}">Cancel</button>`);
    return b.join('');
  }

  function render() {
    const q = query.toLowerCase();
    let list = rows.filter((r) => (status === 'all' || r.status === status) &&
      (!q || [r.food_name, r.ngo_name, r.donor_name].join(' ').toLowerCase().includes(q)));
    if (byPriority) list = [...list].sort((a, b) => (b.priority_score ?? -1) - (a.priority_score ?? -1));
    $('#rows').innerHTML = list.length ? list.map((r) => `<tr>
      <td><strong>${esc(r.food_name)}</strong><span class="sub">#${r.id} · ${SP.fmtDateTime(r.created_at)}</span>${r.message ? `<span class="sub">“${esc(r.message)}”</span>` : ''}</td>
      <td>${esc(r.donor_name)}</td><td>${esc(r.ngo_name)}</td>
      <td class="num nowrap">${SP.fmtQty(r.requested_quantity)} ${esc(r.unit)}</td>
      <td>${SP.pill(r.urgency)}${r.priority_score != null ? `<span class="sub">Score ${r.priority_score}</span>` : ''}</td>
      <td class="nowrap">${SP.fmtDateTime(r.expiry_time)}</td>
      <td>${SP.pill(r.status)}</td>
      <td class="actions">${actionsFor(r)}</td></tr>`).join('')
      : `<tr><td colspan="8">${SP.empty('No requests found', rows.length ? 'Try a different filter.' : 'Requests will appear here once NGOs start asking for food.')}</td></tr>`;
  }

  async function load() {
    try { rows = await SP.api('/api/requests'); renderChips(); render(); }
    catch (e) { $('#rows').innerHTML = `<tr><td colspan="8">${SP.empty('Could not load requests', e.message)}</td></tr>`; }
  }

  $('#search').addEventListener('input', SP.debounce((e) => { query = e.target.value.trim(); render(); }));
  $('#statusChips').addEventListener('click', (e) => { const b = e.target.closest('[data-status]'); if (b) { status = b.dataset.status; renderChips(); render(); } });
  $('#sortBtn').addEventListener('click', (e) => {
    byPriority = !byPriority;
    e.target.textContent = byPriority ? 'Sorted by priority' : 'Sort by priority';
    e.target.classList.toggle('btn-primary', byPriority); e.target.classList.toggle('btn-ghost', !byPriority);
    render();
  });

  $('#rows').addEventListener('click', async (e) => {
    const approve = e.target.closest('[data-approve]'), reject = e.target.closest('[data-reject]'), cancel = e.target.closest('[data-cancel]');
    if (approve) {
      const r = rows.find((x) => x.id == approve.dataset.approve);
      form.reset(); SP.formMessage(form, '');
      form.elements.id.value = r.id;
      $('#approveSummary').textContent = `${SP.fmtQty(r.requested_quantity)} ${r.unit} of ${r.food_name} for ${r.ngo_name}.`;
      SP.openDialog(dlg);
    }
    const act = async (r, path, title, text, ok, done) => {
      if (!(await SP.confirm(title, text, ok, true))) return;
      try { await SP.api(`/api/requests/${r.id}/${path}`, { method: 'POST', body: {} }); SP.toast(done); load(); }
      catch (err) { SP.toast(err.message, 'error'); }
    };
    if (reject) { const r = rows.find((x) => x.id == reject.dataset.reject); act(r, 'reject', 'Reject this request?', `${r.ngo_name} will be told it was not approved.`, 'Reject', 'Request rejected'); }
    if (cancel) { const r = rows.find((x) => x.id == cancel.dataset.cancel); act(r, 'cancel', 'Cancel your request?', `Your request for ${r.food_name} will be withdrawn.`, 'Cancel request', 'Request cancelled'); }
  });

  SP.bindForm(form, async (data) => {
    const id = data.id; delete data.id;
    data.pickup_time = SP.toIso(data.pickup_time);
    await SP.api(`/api/requests/${id}/approve`, { method: 'POST', body: data });
    dlg.close(); SP.toast('Request approved and assignment created'); load();
  });
  load();
})();
