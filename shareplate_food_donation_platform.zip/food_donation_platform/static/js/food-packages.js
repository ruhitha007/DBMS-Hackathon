(function () {
  const { $, esc } = SP;
  let rows = [], status = 'available', query = '', mineOnly = false;
  const canList = SP.isDonor || SP.isAdmin;
  const canRequest = SP.isNgo || SP.isAdmin;

  const STATUSES = ['available', 'allocated', 'expired', 'cancelled', 'all'];

  function renderChips() {
    $('#statusChips').innerHTML = STATUSES.map((s) => {
      const n = s === 'all' ? rows.length : rows.filter((p) => p.status === s).length;
      return `<button class="chip ${s === status ? 'active' : ''}" data-status="${s}">${s === 'all' ? 'All' : SP.label(s)}<span class="count">${n}</span></button>`;
    }).join('');
  }

  function owns(p) { return SP.isAdmin || (SP.isDonor && p.donor_id === SP.user.donor_id); }

  function render() {
    const q = query.toLowerCase();
    const list = rows.filter((p) => (status === 'all' || p.status === status) &&
      (!mineOnly || p.donor_id === SP.user.donor_id) &&
      (!q || [p.food_name, p.donor_name, p.pickup_location].join(' ').toLowerCase().includes(q)));
    $('#grid').innerHTML = list.length ? list.map((p) => {
      const left = SP.timeLeft(p.expiry_time);
      const open = p.status === 'available';
      const buttons = [];
      if (open && canRequest) buttons.push(`<button class="btn btn-accent btn-sm" data-request="${p.id}">Request</button>`);
      if (open && canList && owns(p)) buttons.push(`<button class="btn btn-ghost btn-sm" data-edit="${p.id}">Edit</button>`);
      if ((p.status === 'available' || p.status === 'allocated') && canList && owns(p)) buttons.push(`<button class="btn btn-danger btn-sm" data-cancel="${p.id}">Withdraw</button>`);
      return `<article class="pkg">
        <div class="pkg-top"><h3>${esc(p.food_name)}</h3>${SP.pill(p.status)}</div>
        <div class="donor">${esc(p.donor_name)} · ${esc(SP.label(p.donor_type))}</div>
        <div class="qty">${SP.fmtQty(p.quantity)} <small>${esc(p.unit)} left${p.initial_quantity !== p.quantity ? ' of ' + SP.fmtQty(p.initial_quantity) : ''}</small></div>
        <dl>
          <dt>Expires</dt><dd>${SP.fmtDateTime(p.expiry_time)} · <span class="${left.cls}">${left.text}</span></dd>
          <dt>Pickup</dt><dd>${esc(p.pickup_location)}</dd>
          ${p.notes ? `<dt>Notes</dt><dd>${esc(p.notes)}</dd>` : ''}
          ${p.pending_requests ? `<dt>Requests</dt><dd>${p.pending_requests} pending</dd>` : ''}
        </dl>
        ${buttons.length ? `<div class="pkg-actions">${buttons.join('')}</div>` : ''}
      </article>`;
    }).join('') : SP.empty('No packages found', status === 'available' ? 'No food is listed right now. Check back soon.' : 'Try a different filter.');
  }

  async function load() {
    try { rows = await SP.api('/api/packages'); renderChips(); render(); }
    catch (e) { $('#grid').innerHTML = SP.empty('Could not load packages', e.message); }
  }

  $('#search').addEventListener('input', SP.debounce((e) => { query = e.target.value.trim(); render(); }));
  $('#statusChips').addEventListener('click', (e) => { const b = e.target.closest('[data-status]'); if (b) { status = b.dataset.status; renderChips(); render(); } });
  const mine = $('#mine');
  if (mine) mine.addEventListener('change', () => { mineOnly = mine.checked; render(); });

  /* ----- create / edit package ----- */
  if (canList) {
    const dlg = $('#pkgDialog'), form = $('#pkgForm');
    async function openPkg(p) {
      form.reset(); SP.formMessage(form, '');
      form.elements.id.value = p ? p.id : '';
      $('#pkgTitle').textContent = p ? 'Edit food package' : 'List a food package';
      if (SP.isAdmin && form.donor_id) {
        const donors = await SP.api('/api/donors');
        form.donor_id.innerHTML = '<option value="">Choose donor</option>' + donors.map((d) => `<option value="${d.id}">${esc(d.name)}</option>`).join('');
        form.donor_id.disabled = !!p;
        if (p) form.donor_id.value = p.donor_id;
      }
      if (p) {
        form.food_name.value = p.food_name; form.quantity.value = p.quantity; form.unit.value = p.unit;
        form.expiry_time.value = SP.toLocalInput(p.expiry_time); form.pickup_location.value = p.pickup_location; form.notes.value = p.notes;
      } else {
        const soon = new Date(Date.now() + 6 * 3600 * 1000);
        form.expiry_time.value = SP.toLocalInput(soon.toISOString());
        if (SP.isDonor) {
          SP.api('/api/profile').then((me) => { if (!form.pickup_location.value) form.pickup_location.value = me.address || ''; }).catch(() => {});
        }
      }
      SP.openDialog(dlg);
    }
    $('#addBtn').addEventListener('click', () => openPkg(null));
    SP.bindForm(form, async (data) => {
      const id = data.id; delete data.id;
      if (SP.isAdmin && id) data.donor_id = rows.find((p) => p.id == id).donor_id; // disabled select is not submitted
      data.expiry_time = SP.toIso(data.expiry_time);
      await SP.api(id ? `/api/packages/${id}` : '/api/packages', { method: id ? 'PUT' : 'POST', body: data });
      dlg.close(); SP.toast(id ? 'Package updated' : 'Package listed'); status = 'available'; load();
    });
    $('#grid').addEventListener('click', async (e) => {
      const edit = e.target.closest('[data-edit]'), cancel = e.target.closest('[data-cancel]');
      if (edit) openPkg(rows.find((p) => p.id == edit.dataset.edit));
      if (cancel) {
        const p = rows.find((x) => x.id == cancel.dataset.cancel);
        if (!(await SP.confirm('Withdraw this package?', `"${p.food_name}" will no longer be available and any pending requests will be rejected.`, 'Withdraw', true))) return;
        try { await SP.api(`/api/packages/${p.id}`, { method: 'DELETE' }); SP.toast('Package withdrawn'); load(); }
        catch (err) { SP.toast(err.message, 'error'); }
      }
    });
    if (new URLSearchParams(location.search).get('new') === '1') openPkg(null);
  }

  /* ----- request a package ----- */
  if (canRequest) {
    const dlg = $('#reqDialog'), form = $('#reqForm');
    $('#grid').addEventListener('click', async (e) => {
      const btn = e.target.closest('[data-request]');
      if (!btn) return;
      const p = rows.find((x) => x.id == btn.dataset.request);
      form.reset(); SP.formMessage(form, '');
      form.package_id.value = p.id;
      form.requested_quantity.max = p.quantity; form.requested_quantity.value = p.quantity;
      $('#reqSummary').textContent = `${p.food_name} from ${p.donor_name}. Up to ${SP.fmtQty(p.quantity)} ${p.unit} available.`;
      if (SP.isAdmin && form.ngo_id) {
        const ngos = await SP.api('/api/ngos');
        form.ngo_id.innerHTML = '<option value="">Choose NGO</option>' + ngos.map((n) => `<option value="${n.id}">${esc(n.name)}</option>`).join('');
      }
      SP.openDialog(dlg);
    });
    SP.bindForm(form, async (data) => {
      await SP.api('/api/requests', { method: 'POST', body: data });
      dlg.close(); SP.toast('Request sent to the donor'); load();
    });
  }
  load();
})();
