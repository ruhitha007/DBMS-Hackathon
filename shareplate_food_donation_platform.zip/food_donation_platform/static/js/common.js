/* SharePlate shared helpers. Every page loads this, then its own page script. */
(function () {
  const SP = window.SP;
  const user = SP.user;

  SP.$ = (sel, root = document) => root.querySelector(sel);
  SP.$$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  SP.role = user ? user.role : null;
  SP.isAdmin = SP.role === 'admin';
  SP.isDonor = SP.role === 'donor';
  SP.isNgo = SP.role === 'ngo';

  SP.esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  /* ---- API ---- */
  SP.api = async function (path, { method = 'GET', body } = {}) {
    const res = await fetch(path, {
      method,
      credentials: 'same-origin',
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : {},
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    let data = {};
    try { data = await res.json(); } catch (e) { /* empty body */ }
    if (res.status === 401 && !path.startsWith('/api/auth/login')) {
      window.location.href = '/login?next=' + encodeURIComponent(window.location.pathname);
      throw new Error('Please sign in to continue.');
    }
    if (!res.ok) throw new Error(data.error || 'Something went wrong. Please try again.');
    return data;
  };

  /* ---- Formatting ---- */
  SP.fmtQty = (n) => Number(n).toLocaleString(undefined, { maximumFractionDigits: 2 });
  SP.fmtDateTime = (iso) => iso ? new Date(iso).toLocaleString([], { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }) : '—';
  SP.fmtDate = (iso) => iso ? new Date(iso).toLocaleDateString([], { day: 'numeric', month: 'short', year: 'numeric' }) : '—';
  SP.fmtTotals = (obj) => {
    const parts = Object.entries(obj || {}).map(([u, n]) => `${SP.fmtQty(n)} ${u}`);
    return parts.length ? parts.join(' · ') : '0';
  };
  SP.label = (s) => ({ in_transit: 'In transit', ngo: 'NGO' }[s] || (s ? s.charAt(0).toUpperCase() + s.slice(1) : ''));
  SP.pill = (status) => `<span class="pill pill-${SP.esc(status)}">${SP.esc(SP.label(status))}</span>`;
  SP.timeLeft = (iso) => {
    const mins = Math.round((new Date(iso) - Date.now()) / 60000);
    if (mins <= 0) return { text: 'Expired', cls: 'left-gone' };
    const h = Math.floor(mins / 60);
    const text = h >= 48 ? `${Math.floor(h / 24)}d left` : h >= 1 ? `${h}h ${mins % 60}m left` : `${mins}m left`;
    return { text, cls: h < 6 ? 'left-urgent' : h < 24 ? 'left-soon' : 'left-ok' };
  };
  SP.toLocalInput = (iso) => {
    if (!iso) return '';
    const d = new Date(iso);
    const pad = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  };
  SP.toIso = (localValue) => localValue ? new Date(localValue).toISOString() : null;
  SP.empty = (title, msg = '') => `<div class="empty"><strong>${SP.esc(title)}</strong>${SP.esc(msg)}</div>`;
  SP.debounce = (fn, ms = 200) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

  /* ---- Toast ---- */
  let toastTimer;
  SP.toast = (msg, type = '') => {
    const el = SP.$('#toast');
    el.textContent = msg;
    el.className = type;
    el.style.display = 'block';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.style.display = 'none'; }, 3200);
  };

  /* ---- Dialogs ---- */
  SP.openDialog = (dlg) => { dlg.showModal(); const f = dlg.querySelector('input:not([type=hidden]), select, textarea'); if (f) f.focus(); };
  document.addEventListener('click', (e) => {
    const closer = e.target.closest('[data-close]');
    if (closer) { const d = closer.closest('dialog'); if (d) d.close(); return; }
    if (e.target.tagName === 'DIALOG') e.target.close(); // click on backdrop
  });
  SP.confirm = (title, text, okLabel = 'Confirm', danger = false) => new Promise((resolve) => {
    const dlg = SP.$('#confirmDialog');
    SP.$('#confirmTitle').textContent = title;
    SP.$('#confirmText').textContent = text;
    const ok = SP.$('#confirmOk');
    ok.textContent = okLabel;
    ok.className = 'btn ' + (danger ? 'btn-danger-solid' : 'btn-primary');
    dlg.returnValue = '';
    dlg.addEventListener('close', () => resolve(dlg.returnValue === 'ok'), { once: true });
    dlg.showModal();
  });

  /* ---- Forms ---- */
  SP.formData = (form) => Object.fromEntries(new FormData(form).entries());
  SP.formMessage = (form, msg, ok = false) => {
    let box = form.querySelector('.form-msg');
    if (!box) {
      box = document.createElement('div');
      box.className = 'form-msg';
      box.setAttribute('role', 'alert');
      form.prepend(box);
    }
    box.className = 'form-msg ' + (ok ? 'form-ok' : 'form-error');
    box.textContent = msg;
    box.classList.toggle('hidden', !msg);
  };
  SP.bindForm = (form, handler) => {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = e.submitter || form.querySelector('[type=submit]');
      SP.formMessage(form, '');
      if (btn) btn.disabled = true;
      try { await handler(SP.formData(form), form); }
      catch (err) { SP.formMessage(form, err.message); }
      finally { if (btn) btn.disabled = false; }
    });
  };

  /* ---- Navigation ---- */
  const toggle = SP.$('#navToggle');
  if (toggle) toggle.addEventListener('click', () => {
    const open = SP.$('#siteNav').classList.toggle('open');
    toggle.setAttribute('aria-expanded', open);
  });
  const logout = SP.$('#logoutBtn');
  if (logout) logout.addEventListener('click', async () => {
    try { await SP.api('/api/auth/logout', { method: 'POST', body: {} }); } catch (e) { /* ignore */ }
    window.location.href = '/login';
  });
})();
