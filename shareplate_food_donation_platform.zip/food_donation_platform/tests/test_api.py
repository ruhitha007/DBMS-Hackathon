"""End-to-end API tests. Run with:  python -m unittest discover -s tests -v"""
import os
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# use a throwaway database so the real one is never touched
_TMP = tempfile.mkdtemp()
os.environ["DATABASE_URL"] = "sqlite:///" + os.path.join(_TMP, "test.db")
import app as shareplate  # noqa: E402


def future(hours):
    return (datetime.now(timezone.utc) + timedelta(hours=hours)).isoformat()


class SharePlateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        shareplate.app.config.update(TESTING=True)

    def setUp(self):
        self.app = shareplate.app
        with self.app.app_context():
            shareplate.db.drop_all()
            shareplate.db.create_all()
        self.donor, self.ngo, self.admin, self.other_ngo = (self.app.test_client() for _ in range(4))
        self.donor.post("/api/auth/register", json={"role": "donor", "name": "Green Leaf", "email": "d@x.com",
                                                    "password": "password1", "donor_type": "hotel"})
        self.ngo.post("/api/auth/register", json={"role": "ngo", "name": "Hope Kitchen", "email": "n@x.com", "password": "password1"})
        self.other_ngo.post("/api/auth/register", json={"role": "ngo", "name": "Other NGO", "email": "o@x.com", "password": "password1"})
        with self.app.app_context():
            shareplate.db.session.add(shareplate.User(email="a@x.com", role="admin", name="Admin",
                                                      password_hash=shareplate.generate_password_hash("password1")))
            shareplate.db.session.commit()
        self.admin.post("/api/auth/login", json={"email": "a@x.com", "password": "password1"})

    def package(self, qty=40, hours=10):
        r = self.donor.post("/api/packages", json={"food_name": "Rice", "quantity": qty, "unit": "servings",
                                                   "expiry_time": future(hours), "pickup_location": "Market"})
        self.assertEqual(r.status_code, 201, r.json)
        return r.json["id"]

    def test_pages_are_separate_routes_and_protected(self):
        anon = self.app.test_client()
        for path in ["/", "/login", "/register"]:
            self.assertEqual(anon.get(path).status_code, 200, path)
        for path in ["/dashboard", "/donors", "/ngos", "/food-packages", "/requests", "/assignments",
                     "/distribution-history", "/profile"]:
            r = anon.get(path)
            self.assertEqual(r.status_code, 302, path)
            self.assertIn("/login", r.headers["Location"])
            self.assertEqual(self.donor.get(path).status_code, 200, path)
        self.assertEqual(anon.get("/api/packages").status_code, 401)

    def test_register_validation(self):
        c = self.app.test_client()
        self.assertEqual(c.post("/api/auth/register", json={"role": "donor", "name": "X", "email": "d@x.com", "password": "password1"}).status_code, 409)
        self.assertEqual(c.post("/api/auth/register", json={"role": "donor", "name": "X", "email": "bad", "password": "password1"}).status_code, 400)
        self.assertEqual(c.post("/api/auth/register", json={"role": "donor", "name": "X", "email": "z@x.com", "password": "short"}).status_code, 400)
        self.assertEqual(c.post("/api/auth/login", json={"email": "d@x.com", "password": "wrong"}).status_code, 401)

    def test_full_donation_lifecycle(self):
        pid = self.package(40)
        r = self.ngo.post("/api/requests", json={"package_id": pid, "requested_quantity": 25, "urgency": "high"})
        self.assertEqual(r.status_code, 201, r.json)
        rid = r.json["id"]
        self.assertEqual(self.ngo.post("/api/requests", json={"package_id": pid, "requested_quantity": 5}).status_code, 409)  # duplicate pending
        self.assertEqual(self.other_ngo.post("/api/requests", json={"package_id": pid, "requested_quantity": 99}).status_code, 400)  # too much
        # permissions: NGOs and other donors can't approve
        self.assertEqual(self.ngo.post(f"/api/requests/{rid}/approve", json={}).status_code, 403)
        a = self.donor.post(f"/api/requests/{rid}/approve", json={"assigned_to": "Ravi", "pickup_time": future(2)})
        self.assertEqual(a.status_code, 200, a.json)
        aid = a.json["assignment_id"]
        pkg = self.donor.get("/api/packages").json[0]
        self.assertEqual(pkg["quantity"], 15)
        self.assertEqual(self.donor.post(f"/api/requests/{rid}/approve", json={}).status_code, 409)
        self.assertEqual(self.ngo.post(f"/api/assignments/{aid}/start").status_code, 200)
        self.assertEqual(self.other_ngo.post(f"/api/assignments/{aid}/complete", json={}).status_code, 403)
        self.assertEqual(self.ngo.post(f"/api/assignments/{aid}/complete", json={"distributed_quantity": 30}).status_code, 400)
        done = self.ngo.post(f"/api/assignments/{aid}/complete", json={"distributed_quantity": 20, "notes": "Fed 20"})
        self.assertEqual(done.status_code, 200, done.json)
        # shortfall of 5 goes back to the package
        self.assertEqual(self.donor.get("/api/packages").json[0]["quantity"], 20)
        hist = self.ngo.get("/api/history").json
        self.assertEqual(len(hist), 1)
        self.assertEqual(hist[0]["distributed_quantity"], 20)
        self.assertEqual(self.other_ngo.get("/api/history").json, [])  # scoped
        self.assertEqual(self.ngo.get("/api/requests").json[0]["status"], "completed")
        stats = self.donor.get("/api/stats").json
        self.assertEqual(stats["completed_distributions"], 1)
        self.assertEqual(stats["quantity_by_unit"], {"servings": 20})

    def test_reject_cancel_and_package_withdrawal(self):
        pid = self.package(10)
        rid = self.ngo.post("/api/requests", json={"package_id": pid, "requested_quantity": 10}).json["id"]
        self.assertEqual(self.donor.post(f"/api/requests/{rid}/reject").status_code, 200)
        rid2 = self.other_ngo.post("/api/requests", json={"package_id": pid, "requested_quantity": 10}).json["id"]
        a = self.donor.post(f"/api/requests/{rid2}/approve", json={}).json
        self.assertEqual(self.donor.get("/api/packages").json[0]["status"], "allocated")
        self.assertEqual(self.donor.delete(f"/api/packages/{pid}").status_code, 409)  # active assignment
        self.assertEqual(self.donor.post(f"/api/assignments/{a['assignment_id']}/cancel").status_code, 200)
        pkg = self.donor.get("/api/packages").json[0]
        self.assertEqual((pkg["status"], pkg["quantity"]), ("available", 10))
        self.assertEqual(self.donor.delete(f"/api/packages/{pid}").status_code, 200)
        self.assertEqual(self.donor.get("/api/packages").json[0]["status"], "cancelled")

    def test_package_edit_rules(self):
        pid = self.package(10)
        r = self.donor.put(f"/api/packages/{pid}", json={"food_name": "Rice and dal", "quantity": 12, "unit": "kg",
                                                         "expiry_time": future(8), "pickup_location": "Back gate", "notes": "x"})
        self.assertEqual(r.status_code, 200, r.json)
        self.assertEqual((r.json["food_name"], r.json["quantity"], r.json["unit"]), ("Rice and dal", 12, "kg"))
        self.assertEqual(self.ngo.put(f"/api/packages/{pid}", json={}).status_code, 403)
        self.assertEqual(self.donor.post("/api/packages", json={"food_name": "Old", "quantity": 1, "expiry_time": future(-1),
                                                                "pickup_location": "x"}).status_code, 400)

    def test_admin_management_and_scoping(self):
        self.assertEqual(self.donor.post("/api/donors", json={"name": "A", "email": "a@a.com"}).status_code, 403)
        d = self.admin.post("/api/donors", json={"name": "FreshMart", "email": "fm@x.com", "donor_type": "supermarket"})
        self.assertEqual(d.status_code, 201, d.json)
        self.assertEqual(self.admin.put(f"/api/donors/{d.json['id']}", json={"name": "FreshMart 2", "email": "fm@x.com", "donor_type": "supermarket"}).status_code, 200)
        self.assertEqual(self.admin.delete(f"/api/donors/{d.json['id']}").status_code, 200)
        n = self.admin.post("/api/ngos", json={"name": "Asha", "email": "asha@x.com"})
        self.assertEqual(n.status_code, 201)
        self.assertEqual(len(self.admin.get("/api/ngos").json), 3)
        # admin lists a package for a donor
        donor_id = self.donor.get("/api/auth/me").json["donor_id"]
        r = self.admin.post("/api/packages", json={"donor_id": donor_id, "food_name": "Bread", "quantity": 5, "expiry_time": future(5), "pickup_location": "x"})
        self.assertEqual(r.status_code, 201, r.json)
        # donor with packages cannot be deleted
        self.assertEqual(self.admin.delete(f"/api/donors/{donor_id}").status_code, 409)

    def test_profile_and_password(self):
        self.assertEqual(self.donor.put("/api/profile", json={"name": "Green Leaf 2", "email": "d@x.com", "phone": "1", "address": "A", "donor_type": "restaurant"}).status_code, 200)
        self.assertEqual(self.donor.get("/api/profile").json["name"], "Green Leaf 2")
        self.assertEqual(self.donor.put("/api/profile", json={"name": "G", "email": "n@x.com"}).status_code, 409)
        self.assertEqual(self.donor.post("/api/profile/password", json={"current_password": "bad", "new_password": "newpassword"}).status_code, 403)
        self.assertEqual(self.donor.post("/api/profile/password", json={"current_password": "password1", "new_password": "newpassword"}).status_code, 200)
        c = self.app.test_client()
        self.assertEqual(c.post("/api/auth/login", json={"email": "d@x.com", "password": "newpassword"}).status_code, 200)

    def test_expiry_sweep_and_public_stats(self):
        pid = self.package(10)
        with self.app.app_context():
            p = shareplate.db.session.get(shareplate.FoodPackage, pid)
            p.expiry_time = shareplate.now() - timedelta(minutes=1)
            shareplate.db.session.commit()
        self.assertEqual(self.donor.get("/api/packages").json[0]["status"], "expired")
        s = self.app.test_client().get("/api/public/stats").json
        self.assertEqual((s["donors"], s["ngos"], s["available_packages"]), (1, 2, 0))


if __name__ == "__main__":
    unittest.main()
