"""SharePlate - Food Donation Management Platform.

Flask + SQLite backend. Every page is a separate server-rendered template (MPA);
the pages talk to the REST API under /api for all data.
"""
import os
import re
import secrets
from datetime import datetime, timedelta, timezone
from functools import wraps
from pathlib import Path

from flask import Flask, g, jsonify, redirect, render_template, request, session, url_for
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///food_donation.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(days=14)
os.makedirs(app.instance_path, exist_ok=True)


def _secret_key():
    """SECRET_KEY env var, otherwise a random key generated once and kept in instance/."""
    env = os.environ.get("SECRET_KEY")
    if env:
        return env
    path = Path(app.instance_path) / "secret_key"
    if not path.exists():
        path.write_text(secrets.token_hex(32))
    return path.read_text().strip()


app.secret_key = _secret_key()
db = SQLAlchemy(app)

DONOR_TYPES = ("restaurant", "hotel", "supermarket", "individual", "other")
URGENCIES = ("low", "normal", "high", "critical")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def now():
    """Naive UTC 'now'. All datetimes are stored as naive UTC and sent to clients with a Z suffix."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


# --------------------------------------------------------------------------- models
class Donor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(160), unique=True, nullable=False)
    phone = db.Column(db.String(40), default="")
    address = db.Column(db.String(250), default="")
    donor_type = db.Column(db.String(30), default="restaurant")
    created_at = db.Column(db.DateTime, default=now)
    packages = db.relationship("FoodPackage", back_populates="donor")


class NGO(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(160), unique=True, nullable=False)
    phone = db.Column(db.String(40), default="")
    address = db.Column(db.String(250), default="")
    created_at = db.Column(db.DateTime, default=now)
    requests = db.relationship("DonationRequest", back_populates="ngo")


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(160), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # donor | ngo | admin
    name = db.Column(db.String(120), default="")  # used by admins; donors/NGOs use their organisation name
    donor_id = db.Column(db.Integer, db.ForeignKey("donor.id"), nullable=True)
    ngo_id = db.Column(db.Integer, db.ForeignKey("ngo.id"), nullable=True)
    created_at = db.Column(db.DateTime, default=now)
    donor = db.relationship("Donor")
    ngo = db.relationship("NGO")

    @property
    def display_name(self):
        if self.donor:
            return self.donor.name
        if self.ngo:
            return self.ngo.name
        return self.name or self.email


class FoodPackage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    donor_id = db.Column(db.Integer, db.ForeignKey("donor.id"), nullable=False)
    food_name = db.Column(db.String(160), nullable=False)
    quantity = db.Column(db.Float, nullable=False)  # quantity still available
    initial_quantity = db.Column(db.Float, nullable=True)
    unit = db.Column(db.String(30), default="servings")
    expiry_time = db.Column(db.DateTime, nullable=False)
    pickup_location = db.Column(db.String(250), nullable=False)
    notes = db.Column(db.Text, default="")
    status = db.Column(db.String(30), default="available")  # available | allocated | expired | cancelled
    created_at = db.Column(db.DateTime, default=now)
    donor = db.relationship("Donor", back_populates="packages")
    requests = db.relationship("DonationRequest", back_populates="package")


class DonationRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    package_id = db.Column(db.Integer, db.ForeignKey("food_package.id"), nullable=False)
    ngo_id = db.Column(db.Integer, db.ForeignKey("ngo.id"), nullable=False)
    requested_quantity = db.Column(db.Float, nullable=False)
    urgency = db.Column(db.String(20), default="normal")
    message = db.Column(db.Text, default="")
    # pending | approved | completed | rejected | cancelled | expired
    status = db.Column(db.String(30), default="pending")
    created_at = db.Column(db.DateTime, default=now)
    package = db.relationship("FoodPackage", back_populates="requests")
    ngo = db.relationship("NGO", back_populates="requests")
    assignment = db.relationship("Assignment", back_populates="request", uselist=False)


class Assignment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    request_id = db.Column(db.Integer, db.ForeignKey("donation_request.id"), nullable=False, unique=True)
    assigned_to = db.Column(db.String(120), default="")
    pickup_time = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(30), default="assigned")  # assigned | in_transit | completed | cancelled
    created_at = db.Column(db.DateTime, default=now)
    request = db.relationship("DonationRequest", back_populates="assignment")
    history = db.relationship("DistributionHistory", back_populates="assignment", uselist=False)


class DistributionHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    assignment_id = db.Column(db.Integer, db.ForeignKey("assignment.id"), nullable=False)
    distributed_quantity = db.Column(db.Float, nullable=False)
    distribution_date = db.Column(db.DateTime, default=now)
    notes = db.Column(db.Text, default="")
    assignment = db.relationship("Assignment", back_populates="history")


# --------------------------------------------------------------------------- helpers
class ApiError(Exception):
    def __init__(self, message, code=400):
        super().__init__(message)
        self.message, self.code = message, code


@app.errorhandler(ApiError)
def handle_api_error(e):
    return jsonify({"error": e.message}), e.code


def body():
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}


def parse_dt(value):
    """Parse ISO 8601 into naive UTC. Naive input is treated as UTC."""
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is not None:
        parsed = parsed.astimezone(timezone.utc).replace(tzinfo=None)
    return parsed


def iso(value):
    return value.isoformat(timespec="seconds") + "Z" if value else None


def text(data, key, label, required=False, max_len=250):
    value = data.get(key)
    value = "" if value is None else str(value).strip()
    if required and not value:
        raise ApiError(f"{label} is required.")
    if len(value) > max_len:
        raise ApiError(f"{label} must be {max_len} characters or fewer.")
    return value


def positive_number(data, key, label):
    try:
        number = float(data[key])
    except (KeyError, TypeError, ValueError):
        raise ApiError(f"{label} must be a number.")
    if not number > 0 or number == float("inf"):
        raise ApiError(f"{label} must be greater than zero.")
    return number


def email_field(data):
    email = text(data, "email", "Email", required=True, max_len=160).lower()
    if not EMAIL_RE.match(email):
        raise ApiError("Enter a valid email address.")
    return email


def password_field(value):
    if not isinstance(value, str) or len(value) < 8:
        raise ApiError("Password must be at least 8 characters.")
    return value


def donor_type_field(data, default="restaurant"):
    value = text(data, "donor_type", "Donor type", max_len=30).lower() or default
    if value not in DONOR_TYPES:
        raise ApiError("Choose a valid donor type.")
    return value


def clean_num(n):
    return int(n) if float(n).is_integer() else round(n, 2)


# ----------------------------------------------------------------------- auth / access
def current_user():
    if "current_user" not in g:
        uid = session.get("uid")
        g.current_user = db.session.get(User, uid) if uid else None
    return g.current_user


def user_json(u):
    return {"id": u.id, "email": u.email, "role": u.role, "name": u.display_name,
            "donor_id": u.donor_id, "ngo_id": u.ngo_id, "created_at": iso(u.created_at)}


def api_auth(*roles):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            user = current_user()
            if not user:
                raise ApiError("Please sign in to continue.", 401)
            if roles and user.role not in roles:
                raise ApiError("You do not have permission to do that.", 403)
            return fn(*args, **kwargs)
        return wrapper
    return decorator


def page_auth(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user():
            return redirect(url_for("login_page", next=request.path))
        return fn(*args, **kwargs)
    return wrapper


def scope(query, user):
    """Limit a query (already joined to FoodPackage and DonationRequest) to what the user may see."""
    if user.role == "donor":
        return query.filter(FoodPackage.donor_id == user.donor_id)
    if user.role == "ngo":
        return query.filter(DonationRequest.ngo_id == user.ngo_id)
    return query


def visible_requests(user):
    q = DonationRequest.query.join(FoodPackage, DonationRequest.package_id == FoodPackage.id)
    return scope(q, user)


def visible_assignments(user):
    q = (Assignment.query
         .join(DonationRequest, Assignment.request_id == DonationRequest.id)
         .join(FoodPackage, DonationRequest.package_id == FoodPackage.id))
    return scope(q, user)


def visible_history(user):
    q = (DistributionHistory.query
         .join(Assignment, DistributionHistory.assignment_id == Assignment.id)
         .join(DonationRequest, Assignment.request_id == DonationRequest.id)
         .join(FoodPackage, DonationRequest.package_id == FoodPackage.id))
    return scope(q, user)


def owns_package(user, package):
    return user.role == "admin" or (user.role == "donor" and package.donor_id == user.donor_id)


def is_party(user, req):
    if user.role == "admin":
        return True
    if user.role == "donor":
        return req.package.donor_id == user.donor_id
    return req.ngo_id == user.ngo_id


@app.before_request
def sweep_expired():
    """Mark available packages past their expiry time as expired (and close their pending requests)."""
    if request.endpoint in (None, "static"):
        return
    stale = FoodPackage.query.filter(FoodPackage.status == "available", FoodPackage.expiry_time <= now()).all()
    if not stale:
        return
    for p in stale:
        p.status = "expired"
        for r in p.requests:
            if r.status == "pending":
                r.status = "expired"
    db.session.commit()


@app.after_request
def no_store(resp):
    if request.endpoint != "static":
        resp.headers["Cache-Control"] = "no-store"
    return resp


# --------------------------------------------------------------------------- serializers
def priority_score(urgency, hours_left):
    """Rule-based prioritisation: request urgency + time left before the food expires."""
    urgency_points = {"critical": 50, "high": 30, "normal": 10, "low": 0}.get((urgency or "").lower(), 10)
    expiry_points = 40 if hours_left <= 6 else 30 if hours_left <= 24 else 15 if hours_left <= 48 else 0
    return urgency_points + expiry_points


def donor_json(d):
    return {"id": d.id, "name": d.name, "email": d.email, "phone": d.phone, "address": d.address,
            "donor_type": d.donor_type, "created_at": iso(d.created_at)}


def ngo_json(n):
    return {"id": n.id, "name": n.name, "email": n.email, "phone": n.phone, "address": n.address,
            "created_at": iso(n.created_at)}


def package_json(p):
    return {"id": p.id, "donor_id": p.donor_id, "donor_name": p.donor.name, "donor_type": p.donor.donor_type,
            "food_name": p.food_name, "quantity": p.quantity, "initial_quantity": p.initial_quantity or p.quantity,
            "unit": p.unit, "expiry_time": iso(p.expiry_time), "pickup_location": p.pickup_location,
            "notes": p.notes, "status": p.status, "created_at": iso(p.created_at),
            "pending_requests": sum(1 for r in p.requests if r.status == "pending")}


def request_json(r):
    p = r.package
    hours = (p.expiry_time - now()).total_seconds() / 3600
    return {"id": r.id, "package_id": r.package_id, "food_name": p.food_name, "unit": p.unit,
            "donor_id": p.donor_id, "donor_name": p.donor.name, "ngo_id": r.ngo_id, "ngo_name": r.ngo.name,
            "requested_quantity": r.requested_quantity, "urgency": r.urgency, "status": r.status,
            "message": r.message, "created_at": iso(r.created_at), "expiry_time": iso(p.expiry_time),
            "hours_until_expiry": round(hours, 1),
            "priority_score": priority_score(r.urgency, hours) if r.status == "pending" else None,
            "assignment_id": r.assignment.id if r.assignment else None}


def assignment_json(a):
    r = a.request
    p = r.package
    return {"id": a.id, "request_id": r.id, "assigned_to": a.assigned_to, "status": a.status,
            "pickup_time": iso(a.pickup_time), "created_at": iso(a.created_at),
            "food_name": p.food_name, "unit": p.unit, "quantity": r.requested_quantity,
            "pickup_location": p.pickup_location, "expiry_time": iso(p.expiry_time),
            "donor_id": p.donor_id, "donor_name": p.donor.name, "ngo_id": r.ngo_id, "ngo_name": r.ngo.name}


def history_json(h):
    a = h.assignment
    r = a.request
    p = r.package
    return {"id": h.id, "assignment_id": a.id, "request_id": r.id, "food_name": p.food_name, "unit": p.unit,
            "donor_id": p.donor_id, "donor_name": p.donor.name, "ngo_id": r.ngo_id, "ngo_name": r.ngo.name,
            "assigned_to": a.assigned_to, "distributed_quantity": h.distributed_quantity,
            "distribution_date": iso(h.distribution_date), "notes": h.notes}


def totals_by_unit(history_rows):
    totals = {}
    for h in history_rows:
        unit = h.assignment.request.package.unit or "items"
        totals[unit] = totals.get(unit, 0) + h.distributed_quantity
    return {u: clean_num(v) for u, v in totals.items()}


# --------------------------------------------------------------------------- page routes
@app.context_processor
def inject_user():
    user = current_user()
    return {"current_user": user_json(user) if user else None}


@app.get("/")
def home():
    return render_template("index.html")


@app.get("/login")
def login_page():
    if current_user():
        return redirect(url_for("dashboard_page"))
    return render_template("login.html")


@app.get("/register")
def register_page():
    if current_user():
        return redirect(url_for("dashboard_page"))
    return render_template("register.html")


def _page(name, template):
    @page_auth
    def view():
        return render_template(template)
    app.add_url_rule(name, endpoint=template.replace(".html", "").replace("-", "_") + "_page", view_func=view)


_page("/dashboard", "dashboard.html")
_page("/donors", "donors.html")
_page("/ngos", "ngos.html")
_page("/food-packages", "food-packages.html")
_page("/requests", "requests.html")
_page("/assignments", "assignments.html")
_page("/distribution-history", "distribution-history.html")
_page("/profile", "profile.html")


@app.errorhandler(404)
def not_found(_):
    if request.path.startswith("/api/"):
        return jsonify({"error": "Not found."}), 404
    return render_template("404.html"), 404


@app.errorhandler(405)
def method_not_allowed(_):
    return jsonify({"error": "Method not allowed."}), 405


# --------------------------------------------------------------------------- auth API
@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "service": "SharePlate Food Donation Management Platform"})


@app.post("/api/auth/register")
def register():
    data = body()
    role = text(data, "role", "Account type").lower()
    if role not in ("donor", "ngo"):
        raise ApiError("Choose whether you are registering as a donor or an NGO.")
    name = text(data, "name", "Name", required=True, max_len=120)
    email = email_field(data)
    password = password_field(data.get("password"))
    phone = text(data, "phone", "Phone", max_len=40)
    address = text(data, "address", "Address", max_len=250)
    if User.query.filter_by(email=email).first() or Donor.query.filter_by(email=email).first() \
            or NGO.query.filter_by(email=email).first():
        raise ApiError("An account with this email already exists.", 409)
    user = User(email=email, password_hash=generate_password_hash(password), role=role)
    if role == "donor":
        user.donor = Donor(name=name, email=email, phone=phone, address=address, donor_type=donor_type_field(data))
    else:
        user.ngo = NGO(name=name, email=email, phone=phone, address=address)
    db.session.add(user)
    db.session.commit()
    session.clear()
    session["uid"] = user.id
    session.permanent = True
    return jsonify(user_json(user)), 201


@app.post("/api/auth/login")
def login():
    data = body()
    email = str(data.get("email") or "").strip().lower()
    user = User.query.filter_by(email=email).first()
    if not user or not check_password_hash(user.password_hash, str(data.get("password") or "")):
        raise ApiError("Incorrect email or password.", 401)
    session.clear()
    session["uid"] = user.id
    session.permanent = True
    return jsonify(user_json(user))


@app.post("/api/auth/logout")
def logout():
    session.clear()
    return jsonify({"ok": True})


@app.get("/api/auth/me")
@api_auth()
def me():
    return jsonify(user_json(current_user()))


# --------------------------------------------------------------------------- profile
@app.get("/api/profile")
@api_auth()
def get_profile():
    u = current_user()
    out = user_json(u)
    entity = u.donor or u.ngo
    out.update({"phone": entity.phone if entity else "", "address": entity.address if entity else "",
                "donor_type": u.donor.donor_type if u.donor else None})
    if u.role == "donor":
        pkgs = FoodPackage.query.filter_by(donor_id=u.donor_id).all()
        out["summary"] = {"packages": len(pkgs),
                          "distributions": visible_history(u).count()}
    elif u.role == "ngo":
        out["summary"] = {"packages": None, "requests": visible_requests(u).count(),
                          "distributions": visible_history(u).count()}
    else:
        out["summary"] = {"donors": Donor.query.count(), "ngos": NGO.query.count(),
                          "distributions": DistributionHistory.query.count()}
    return jsonify(out)


@app.put("/api/profile")
@api_auth()
def update_profile():
    u = current_user()
    data = body()
    name = text(data, "name", "Name", required=True, max_len=120)
    email = email_field(data)
    clash = User.query.filter(User.email == email, User.id != u.id).first()
    if clash:
        raise ApiError("Another account already uses this email.", 409)
    entity = u.donor or u.ngo
    if entity:
        model = Donor if u.donor else NGO
        if model.query.filter(model.email == email, model.id != entity.id).first():
            raise ApiError("Another account already uses this email.", 409)
        entity.name, entity.email = name, email
        entity.phone = text(data, "phone", "Phone", max_len=40)
        entity.address = text(data, "address", "Address", max_len=250)
        if u.donor:
            entity.donor_type = donor_type_field(data, entity.donor_type)
    else:
        u.name = name
    u.email = email
    db.session.commit()
    return jsonify(user_json(u))


@app.post("/api/profile/password")
@api_auth()
def change_password():
    u = current_user()
    data = body()
    if not check_password_hash(u.password_hash, str(data.get("current_password") or "")):
        raise ApiError("Current password is incorrect.", 403)
    u.password_hash = generate_password_hash(password_field(data.get("new_password")))
    db.session.commit()
    return jsonify({"ok": True})


# --------------------------------------------------------------------------- public stats
@app.get("/api/public/stats")
def public_stats():
    history_rows = DistributionHistory.query.all()
    available = (FoodPackage.query.filter(FoodPackage.status == "available")
                 .order_by(FoodPackage.expiry_time.asc()).all())
    return jsonify({
        "donors": Donor.query.count(), "ngos": NGO.query.count(),
        "available_packages": len(available), "distributions": len(history_rows),
        "quantity_by_unit": totals_by_unit(history_rows),
        # no pickup address on the public page
        "available_now": [{"food_name": p.food_name, "quantity": p.quantity, "unit": p.unit,
                           "donor_name": p.donor.name, "donor_type": p.donor.donor_type,
                           "expiry_time": iso(p.expiry_time)} for p in available[:6]],
    })


# --------------------------------------------------------------------------- donors & NGOs
@app.get("/api/donors")
@api_auth()
def list_donors():
    rows = Donor.query.order_by(Donor.name).all()
    pkg_counts = dict(db.session.query(FoodPackage.donor_id, func.count(FoodPackage.id))
                      .group_by(FoodPackage.donor_id).all())
    done = dict(db.session.query(FoodPackage.donor_id, func.count(DistributionHistory.id))
                .select_from(DistributionHistory)
                .join(Assignment, DistributionHistory.assignment_id == Assignment.id)
                .join(DonationRequest, Assignment.request_id == DonationRequest.id)
                .join(FoodPackage, DonationRequest.package_id == FoodPackage.id)
                .group_by(FoodPackage.donor_id).all())
    return jsonify([{**donor_json(d), "package_count": pkg_counts.get(d.id, 0),
                     "distribution_count": done.get(d.id, 0)} for d in rows])


@app.post("/api/donors")
@api_auth("admin")
def create_donor():
    data = body()
    email = email_field(data)
    if Donor.query.filter_by(email=email).first():
        raise ApiError("A donor with this email already exists.", 409)
    donor = Donor(name=text(data, "name", "Name", required=True, max_len=120), email=email,
                  phone=text(data, "phone", "Phone", max_len=40), address=text(data, "address", "Address"),
                  donor_type=donor_type_field(data))
    db.session.add(donor)
    db.session.commit()
    return jsonify(donor_json(donor)), 201


def _update_org(model, serializer, org_id, is_donor):
    org = db.session.get(model, org_id)
    if not org:
        raise ApiError("Record not found.", 404)
    data = body()
    email = email_field(data)
    if model.query.filter(model.email == email, model.id != org.id).first():
        raise ApiError("This email is already in use.", 409)
    linked = User.query.filter_by(**{("donor_id" if is_donor else "ngo_id"): org.id}).first()
    if linked and User.query.filter(User.email == email, User.id != linked.id).first():
        raise ApiError("This email is already in use.", 409)
    org.name = text(data, "name", "Name", required=True, max_len=120)
    org.email = email
    org.phone = text(data, "phone", "Phone", max_len=40)
    org.address = text(data, "address", "Address")
    if is_donor:
        org.donor_type = donor_type_field(data, org.donor_type)
    if linked:
        linked.email = email
    db.session.commit()
    return jsonify(serializer(org))


@app.put("/api/donors/<int:donor_id>")
@api_auth("admin")
def update_donor(donor_id):
    return _update_org(Donor, donor_json, donor_id, True)


@app.delete("/api/donors/<int:donor_id>")
@api_auth("admin")
def delete_donor(donor_id):
    donor = db.session.get(Donor, donor_id)
    if not donor:
        raise ApiError("Donor not found.", 404)
    if donor.packages:
        raise ApiError("This donor has food packages on record and cannot be deleted.", 409)
    User.query.filter_by(donor_id=donor.id).delete()
    db.session.delete(donor)
    db.session.commit()
    return jsonify({"ok": True})


@app.get("/api/ngos")
@api_auth()
def list_ngos():
    rows = NGO.query.order_by(NGO.name).all()
    req_counts = dict(db.session.query(DonationRequest.ngo_id, func.count(DonationRequest.id))
                      .group_by(DonationRequest.ngo_id).all())
    done = dict(db.session.query(DonationRequest.ngo_id, func.count(DistributionHistory.id))
                .select_from(DistributionHistory)
                .join(Assignment, DistributionHistory.assignment_id == Assignment.id)
                .join(DonationRequest, Assignment.request_id == DonationRequest.id)
                .group_by(DonationRequest.ngo_id).all())
    return jsonify([{**ngo_json(n), "request_count": req_counts.get(n.id, 0),
                     "distribution_count": done.get(n.id, 0)} for n in rows])


@app.post("/api/ngos")
@api_auth("admin")
def create_ngo():
    data = body()
    email = email_field(data)
    if NGO.query.filter_by(email=email).first():
        raise ApiError("An NGO with this email already exists.", 409)
    ngo = NGO(name=text(data, "name", "Name", required=True, max_len=120), email=email,
              phone=text(data, "phone", "Phone", max_len=40), address=text(data, "address", "Address"))
    db.session.add(ngo)
    db.session.commit()
    return jsonify(ngo_json(ngo)), 201


@app.put("/api/ngos/<int:ngo_id>")
@api_auth("admin")
def update_ngo(ngo_id):
    return _update_org(NGO, ngo_json, ngo_id, False)


@app.delete("/api/ngos/<int:ngo_id>")
@api_auth("admin")
def delete_ngo(ngo_id):
    ngo = db.session.get(NGO, ngo_id)
    if not ngo:
        raise ApiError("NGO not found.", 404)
    if ngo.requests:
        raise ApiError("This NGO has donation requests on record and cannot be deleted.", 409)
    User.query.filter_by(ngo_id=ngo.id).delete()
    db.session.delete(ngo)
    db.session.commit()
    return jsonify({"ok": True})


# --------------------------------------------------------------------------- food packages
@app.get("/api/packages")
@api_auth()
def list_packages():
    user = current_user()
    query = FoodPackage.query
    status = request.args.get("status")
    if status:
        query = query.filter_by(status=status)
    if request.args.get("mine") == "1" and user.role == "donor":
        query = query.filter_by(donor_id=user.donor_id)
    rows = query.order_by(FoodPackage.expiry_time.asc()).all()
    return jsonify([package_json(p) for p in rows])


@app.post("/api/packages")
@api_auth("donor", "admin")
def create_package():
    user = current_user()
    data = body()
    donor_id = user.donor_id if user.role == "donor" else data.get("donor_id")
    try:
        donor = db.session.get(Donor, int(donor_id))
    except (TypeError, ValueError):
        donor = None
    if not donor:
        raise ApiError("Choose a donor for this package.", 400 if donor_id in (None, "") else 404)
    quantity = positive_number(data, "quantity", "Quantity")
    expiry = parse_dt(data.get("expiry_time"))
    if not expiry:
        raise ApiError("Expiry time is required and must be a valid date and time.")
    if expiry <= now():
        raise ApiError("Expiry time must be in the future.")
    package = FoodPackage(donor_id=donor.id, food_name=text(data, "food_name", "Food name", True, 160),
                          quantity=quantity, initial_quantity=quantity,
                          unit=text(data, "unit", "Unit", max_len=30) or "servings", expiry_time=expiry,
                          pickup_location=text(data, "pickup_location", "Pickup location", True),
                          notes=text(data, "notes", "Notes", max_len=1000))
    db.session.add(package)
    db.session.commit()
    return jsonify(package_json(package)), 201


@app.put("/api/packages/<int:package_id>")
@api_auth("donor", "admin")
def update_package(package_id):
    package = db.session.get(FoodPackage, package_id)
    if not package:
        raise ApiError("Package not found.", 404)
    if not owns_package(current_user(), package):
        raise ApiError("You can only edit your own packages.", 403)
    if package.status != "available":
        raise ApiError("Only available packages can be edited.", 409)
    data = body()
    package.food_name = text(data, "food_name", "Food name", True, 160)
    package.unit = text(data, "unit", "Unit", max_len=30) or package.unit
    package.pickup_location = text(data, "pickup_location", "Pickup location", True)
    package.notes = text(data, "notes", "Notes", max_len=1000)
    expiry = parse_dt(data.get("expiry_time"))
    if not expiry or expiry <= now():
        raise ApiError("Expiry time must be a valid time in the future.")
    package.expiry_time = expiry
    quantity = positive_number(data, "quantity", "Quantity")
    package.initial_quantity = (package.initial_quantity or package.quantity) + (quantity - package.quantity)
    package.quantity = quantity
    db.session.commit()
    return jsonify(package_json(package))


@app.delete("/api/packages/<int:package_id>")
@api_auth("donor", "admin")
def cancel_package(package_id):
    package = db.session.get(FoodPackage, package_id)
    if not package:
        raise ApiError("Package not found.", 404)
    if not owns_package(current_user(), package):
        raise ApiError("You can only withdraw your own packages.", 403)
    if package.status in ("cancelled", "expired"):
        raise ApiError(f"This package is already {package.status}.", 409)
    if any(r.assignment and r.assignment.status in ("assigned", "in_transit") for r in package.requests):
        raise ApiError("Complete or cancel the active assignments for this package first.", 409)
    for r in package.requests:
        if r.status == "pending":
            r.status = "rejected"
    package.status = "cancelled"
    db.session.commit()
    return jsonify(package_json(package))


# --------------------------------------------------------------------------- requests
@app.get("/api/requests")
@api_auth()
def list_requests():
    q = visible_requests(current_user())
    status = request.args.get("status")
    if status:
        q = q.filter(DonationRequest.status == status)
    return jsonify([request_json(r) for r in q.order_by(DonationRequest.created_at.desc()).all()])


@app.post("/api/requests")
@api_auth("ngo", "admin")
def create_request():
    user = current_user()
    data = body()
    ngo_id = user.ngo_id if user.role == "ngo" else data.get("ngo_id")
    try:
        ngo = db.session.get(NGO, int(ngo_id))
        package = db.session.get(FoodPackage, int(data.get("package_id")))
    except (TypeError, ValueError):
        raise ApiError("Choose a food package and an NGO.")
    if not ngo:
        raise ApiError("NGO not found.", 404)
    if not package or package.status != "available":
        raise ApiError("This package is no longer available.", 409)
    quantity = positive_number(data, "requested_quantity", "Requested quantity")
    if quantity > package.quantity:
        raise ApiError(f"Requested quantity cannot exceed what is available ({clean_num(package.quantity)} {package.unit}).")
    urgency = text(data, "urgency", "Urgency", max_len=20).lower() or "normal"
    if urgency not in URGENCIES:
        raise ApiError("Choose a valid urgency.")
    if DonationRequest.query.filter_by(package_id=package.id, ngo_id=ngo.id, status="pending").first():
        raise ApiError("This NGO already has a pending request for this package.", 409)
    req = DonationRequest(package_id=package.id, ngo_id=ngo.id, requested_quantity=quantity, urgency=urgency,
                          message=text(data, "message", "Message", max_len=500))
    db.session.add(req)
    db.session.commit()
    return jsonify(request_json(req)), 201


def release_quantity(package, amount):
    """Return unused quantity to a package and re-open it if it still has time left."""
    package.quantity += amount
    if package.status == "allocated" and package.quantity > 0 and package.expiry_time > now():
        package.status = "available"


def get_request_or_404(request_id):
    req = db.session.get(DonationRequest, request_id)
    if not req:
        raise ApiError("Request not found.", 404)
    return req


def approve(req, assigned_to="", pickup_time=None):
    package = req.package
    if req.status != "pending":
        raise ApiError("Only pending requests can be approved.", 409)
    if package.status != "available" or package.expiry_time <= now() or req.requested_quantity > package.quantity:
        raise ApiError("The package is no longer available in the requested quantity.", 409)
    req.status = "approved"
    package.quantity -= req.requested_quantity
    if package.quantity <= 0:
        package.quantity, package.status = 0, "allocated"
    assignment = Assignment(request=req, assigned_to=assigned_to or f"{req.ngo.name} pickup team",
                            pickup_time=pickup_time)
    db.session.add(assignment)
    return assignment


@app.post("/api/requests/<int:request_id>/approve")
@api_auth("donor", "admin")
def approve_request(request_id):
    req = get_request_or_404(request_id)
    if not is_party(current_user(), req):
        raise ApiError("You can only approve requests for your own packages.", 403)
    data = body()
    pickup = None
    if data.get("pickup_time"):
        pickup = parse_dt(data["pickup_time"])
        if not pickup:
            raise ApiError("Pickup time must be a valid date and time.")
    assignment = approve(req, text(data, "assigned_to", "Assigned to", max_len=120), pickup)
    db.session.commit()
    return jsonify({"request_id": req.id, "status": req.status, "assignment_id": assignment.id})


@app.post("/api/requests/<int:request_id>/reject")
@api_auth("donor", "admin")
def reject_request(request_id):
    req = get_request_or_404(request_id)
    if not is_party(current_user(), req):
        raise ApiError("You can only reject requests for your own packages.", 403)
    if req.status != "pending":
        raise ApiError("Only pending requests can be rejected.", 409)
    req.status = "rejected"
    db.session.commit()
    return jsonify({"request_id": req.id, "status": req.status})


@app.post("/api/requests/<int:request_id>/cancel")
@api_auth("ngo", "admin")
def cancel_request(request_id):
    req = get_request_or_404(request_id)
    if not is_party(current_user(), req):
        raise ApiError("You can only cancel your own requests.", 403)
    if req.status != "pending":
        raise ApiError("Only pending requests can be cancelled.", 409)
    req.status = "cancelled"
    db.session.commit()
    return jsonify({"request_id": req.id, "status": req.status})


@app.get("/api/priority")
@api_auth()
def priority():
    rows = visible_requests(current_user()).filter(DonationRequest.status == "pending").all()
    ranked = [{"request_id": r.id, "food_name": r.package.food_name, "ngo_name": r.ngo.name,
               "donor_name": r.package.donor.name, "urgency": r.urgency,
               "requested_quantity": r.requested_quantity, "unit": r.package.unit,
               "hours_until_expiry": round((r.package.expiry_time - now()).total_seconds() / 3600, 1),
               "priority_score": priority_score(r.urgency, (r.package.expiry_time - now()).total_seconds() / 3600)}
              for r in rows]
    ranked.sort(key=lambda x: x["priority_score"], reverse=True)
    return jsonify(ranked)


# --------------------------------------------------------------------------- assignments
def get_assignment_or_404(assignment_id):
    a = db.session.get(Assignment, assignment_id)
    if not a:
        raise ApiError("Assignment not found.", 404)
    return a


@app.get("/api/assignments")
@api_auth()
def list_assignments():
    q = visible_assignments(current_user())
    status = request.args.get("status")
    if status:
        q = q.filter(Assignment.status == status)
    return jsonify([assignment_json(a) for a in q.order_by(Assignment.id.desc()).all()])


@app.put("/api/assignments/<int:assignment_id>")
@api_auth("donor", "admin")
def update_assignment(assignment_id):
    a = get_assignment_or_404(assignment_id)
    if not is_party(current_user(), a.request):
        raise ApiError("You can only edit assignments for your own packages.", 403)
    if a.status not in ("assigned", "in_transit"):
        raise ApiError("This assignment is closed and can no longer be edited.", 409)
    data = body()
    a.assigned_to = text(data, "assigned_to", "Assigned to", required=True, max_len=120)
    if data.get("pickup_time"):
        pickup = parse_dt(data["pickup_time"])
        if not pickup:
            raise ApiError("Pickup time must be a valid date and time.")
        a.pickup_time = pickup
    else:
        a.pickup_time = None
    db.session.commit()
    return jsonify(assignment_json(a))


@app.post("/api/assignments/<int:assignment_id>/start")
@api_auth()
def start_assignment(assignment_id):
    a = get_assignment_or_404(assignment_id)
    if not is_party(current_user(), a.request):
        raise ApiError("You are not part of this assignment.", 403)
    if a.status != "assigned":
        raise ApiError("Only assignments that are waiting for pickup can be marked in transit.", 409)
    a.status = "in_transit"
    db.session.commit()
    return jsonify(assignment_json(a))


@app.post("/api/assignments/<int:assignment_id>/complete")
@api_auth()
def complete_assignment(assignment_id):
    a = get_assignment_or_404(assignment_id)
    req = a.request
    if not is_party(current_user(), req):
        raise ApiError("You are not part of this assignment.", 403)
    if a.status in ("completed", "cancelled"):
        raise ApiError(f"This assignment is already {a.status}.", 409)
    data = body()
    quantity = req.requested_quantity
    if data.get("distributed_quantity") not in (None, ""):
        quantity = positive_number(data, "distributed_quantity", "Distributed quantity")
        if quantity > req.requested_quantity:
            raise ApiError("Distributed quantity cannot exceed the approved quantity "
                           f"({clean_num(req.requested_quantity)}).")
    shortfall = req.requested_quantity - quantity
    if shortfall > 0:
        release_quantity(req.package, shortfall)
    a.status = "completed"
    req.status = "completed"
    db.session.add(DistributionHistory(assignment=a, distributed_quantity=quantity,
                                       notes=text(data, "notes", "Notes", max_len=1000)))
    db.session.commit()
    return jsonify({"assignment_id": a.id, "status": a.status})


@app.post("/api/assignments/<int:assignment_id>/cancel")
@api_auth("donor", "admin")
def cancel_assignment(assignment_id):
    a = get_assignment_or_404(assignment_id)
    req = a.request
    if not is_party(current_user(), req):
        raise ApiError("You can only cancel assignments for your own packages.", 403)
    if a.status not in ("assigned", "in_transit"):
        raise ApiError("Only active assignments can be cancelled.", 409)
    a.status = "cancelled"
    req.status = "cancelled"
    release_quantity(req.package, req.requested_quantity)
    db.session.commit()
    return jsonify(assignment_json(a))


# --------------------------------------------------------------------------- history & stats
@app.get("/api/history")
@api_auth()
def history():
    rows = visible_history(current_user()).order_by(DistributionHistory.distribution_date.desc()).all()
    return jsonify([history_json(h) for h in rows])


@app.get("/api/stats")
@api_auth()
def stats():
    user = current_user()
    requests_ = visible_requests(user).all()
    assignments = visible_assignments(user).all()
    history_rows = visible_history(user).all()
    pkg_q = FoodPackage.query.filter(FoodPackage.status == "available")
    if user.role == "donor":
        pkg_q = pkg_q.filter(FoodPackage.donor_id == user.donor_id)
    available = pkg_q.order_by(FoodPackage.expiry_time.asc()).all()

    status_counts = {}
    for r in requests_:
        status_counts[r.status] = status_counts.get(r.status, 0) + 1

    today = now().date()
    days = [today - timedelta(days=i) for i in range(6, -1, -1)]
    per_day = {d: 0 for d in days}
    for h in history_rows:
        d = h.distribution_date.date()
        if d in per_day:
            per_day[d] += 1

    soon_cutoff = now() + timedelta(hours=24)
    return jsonify({
        "role": user.role,
        "available_packages": len(available),
        "pending_requests": status_counts.get("pending", 0),
        "active_assignments": sum(1 for a in assignments if a.status in ("assigned", "in_transit")),
        "completed_distributions": len(history_rows),
        "quantity_by_unit": totals_by_unit(history_rows),
        "donors": Donor.query.count(), "ngos": NGO.query.count(),
        "request_status": status_counts,
        "expiring_soon": [package_json(p) for p in available if p.expiry_time <= soon_cutoff][:5],
        "daily_distributions": [{"date": d.isoformat(), "count": per_day[d]} for d in days],
        "recent_requests": [request_json(r) for r in sorted(requests_, key=lambda r: r.created_at, reverse=True)[:6]],
    })


# --------------------------------------------------------------------------- CLI
with app.app_context():
    db.create_all()


@app.cli.command("create-admin")
def create_admin():
    """Create an administrator account (prompts for email and password)."""
    import getpass
    email = input("Admin email: ").strip().lower()
    password = getpass.getpass("Password (min 8 chars): ")
    if not EMAIL_RE.match(email) or len(password) < 8:
        print("Invalid email or password too short.")
        return
    if User.query.filter_by(email=email).first():
        print("A user with this email already exists.")
        return
    db.session.add(User(email=email, role="admin", name="Administrator", password_hash=generate_password_hash(password)))
    db.session.commit()
    print("Admin created.")


@app.cli.command("seed")
def seed():
    """Load optional demo data (demo accounts + a realistic mix of packages, requests and history)."""
    if Donor.query.first() or User.query.first():
        print("Database already has data; seed skipped.")
        return
    pw = generate_password_hash("Password@123")
    t = now()

    def donor(name, email, kind, phone, address, login=False):
        d = Donor(name=name, email=email, donor_type=kind, phone=phone, address=address)
        db.session.add(d)
        if login:
            db.session.add(User(email=email, role="donor", donor=d, password_hash=pw))
        return d

    def ngo(name, email, phone, address, login=False):
        n = NGO(name=name, email=email, phone=phone, address=address)
        db.session.add(n)
        if login:
            db.session.add(User(email=email, role="ngo", ngo=n, password_hash=pw))
        return n

    db.session.add(User(email="admin@shareplate.local", role="admin", name="Platform Admin", password_hash=pw))
    leaf = donor("Green Leaf Restaurant", "donor@example.com", "restaurant", "9000000001", "12 Central Market", True)
    hotel = donor("Grand Meridian Hotel", "hotel@example.com", "hotel", "9000000003", "88 Lakeview Road", True)
    mart = donor("FreshMart Supermarket", "freshmart@example.com", "supermarket", "9000000004", "5 High Street")
    anita = donor("Anita Rao", "anita@example.com", "individual", "9000000005", "Flat 4B, Palm Residency")
    hope = ngo("Hope Community Kitchen", "ngo@example.com", "9000000002", "21 Community Road", True)
    roti = ngo("Roti Bank Foundation", "rotibank@example.com", "9000000006", "7 Station Lane", True)
    asha = ngo("Asha Shelter Trust", "asha@example.com", "9000000007", "Old Town Shelter, East Gate")
    db.session.flush()

    def package(donor_, food, qty, unit, hours, where, notes="", created_hours_ago=1):
        p = FoodPackage(donor=donor_, food_name=food, quantity=qty, initial_quantity=qty, unit=unit,
                        expiry_time=t + timedelta(hours=hours), pickup_location=where, notes=notes,
                        created_at=t - timedelta(hours=created_hours_ago))
        db.session.add(p)
        return p

    # historic, fully distributed packages (expired in the past) -> completed history
    past = [(leaf, "Vegetable biryani", 60, "servings", 150, hope, "Priya N."),
            (hotel, "Buffet dinner leftovers", 80, "servings", 126, roti, "Ravi K."),
            (mart, "Bread and bakery items", 35, "kg", 100, asha, "Meena S."),
            (leaf, "Dal and chapati", 45, "servings", 76, hope, "Priya N."),
            (anita, "Home-cooked meals", 12, "servings", 52, roti, "Ravi K."),
            (hotel, "Fruit platters", 20, "kg", 30, asha, "Meena S."),
            (mart, "Packaged snacks", 50, "packets", 8, hope, "Priya N.")]
    for d, food, qty, unit, ago, n, who in past:
        p = package(d, food, qty, unit, -(ago - 12), d.address, "", ago + 6)
        p.quantity, p.status = 0, "allocated"
        r = DonationRequest(package=p, ngo=n, requested_quantity=qty, urgency="normal", status="completed",
                            created_at=t - timedelta(hours=ago + 3))
        a = Assignment(request=r, assigned_to=who, status="completed", pickup_time=t - timedelta(hours=ago),
                       created_at=t - timedelta(hours=ago + 2))
        db.session.add(DistributionHistory(assignment=a, distributed_quantity=qty,
                                           distribution_date=t - timedelta(hours=ago - 2),
                                           notes="Delivered and distributed on site."))

    # live packages
    p1 = package(leaf, "Paneer curry and rice", 40, "servings", 4, "12 Central Market", "Keep warm, container provided")
    p2 = package(hotel, "Assorted sandwiches", 30, "packets", 9, "Hotel service entrance, 88 Lakeview Road")
    p3 = package(mart, "Fresh vegetables", 25, "kg", 30, "FreshMart loading bay", "Slightly bruised, safe to cook today")
    p4 = package(leaf, "Vegetable pulao", 50, "servings", 20, "12 Central Market")
    p5 = package(anita, "Idli and sambar", 15, "servings", 6, "Palm Residency gate")
    p6 = package(hotel, "Milk and dairy cartons", 40, "items", 60, "88 Lakeview Road", "Refrigerated until pickup")
    db.session.flush()

    # pending requests
    db.session.add_all([
        DonationRequest(package=p1, ngo=hope, requested_quantity=25, urgency="critical", message="Evening meal for 60 residents."),
        DonationRequest(package=p1, ngo=asha, requested_quantity=15, urgency="high"),
        DonationRequest(package=p3, ngo=roti, requested_quantity=15, urgency="normal"),
        DonationRequest(package=p4, ngo=hope, requested_quantity=30, urgency="low"),
    ])
    rejected = DonationRequest(package=p6, ngo=asha, requested_quantity=10, urgency="low", status="rejected")
    db.session.add(rejected)
    # approved requests with assignments, one already in transit
    r_a = DonationRequest(package=p2, ngo=roti, requested_quantity=20, urgency="high")
    r_b = DonationRequest(package=p5, ngo=asha, requested_quantity=10, urgency="normal")
    db.session.add_all([r_a, r_b])
    db.session.flush()
    a1 = approve(r_a, "Ravi K.", t + timedelta(hours=1))
    a2 = approve(r_b, "Meena S.", t + timedelta(minutes=45))
    a2.status = "in_transit"
    db.session.commit()
    print("Demo data loaded. Accounts (password for all: Password@123):")
    print("  admin  -> admin@shareplate.local")
    print("  donor  -> donor@example.com, hotel@example.com")
    print("  ngo    -> ngo@example.com, rotibank@example.com")


if __name__ == "__main__":
    app.run(debug=True)
